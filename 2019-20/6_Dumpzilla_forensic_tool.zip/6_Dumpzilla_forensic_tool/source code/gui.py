import tkinter as tk                
from tkinter import font  as tkfont
from tkinter import *
from tkinter import filedialog
import tkinter
from tkinter import ttk
import requests
import sqlite3
import browser_cookie3
import os


#folder_path = str(path.splitdrive('C:/Users/Laptop/AppData/Roaming/Mozilla/Firefox/Profiles/1qfx4rpt.default'))
folder_path = str('C:/Users/Laptop/AppData/Roaming/Mozilla/Firefox/Profiles/1qfx4rpt.default')

def show_downloads_history():
    con = os.path.expanduser('~')+"/AppData/Roaming/Mozilla/Firefox/Profiles/1qfx4rpt.default"
    files = os.listdir(con)

    history = os.path.join(con,'places.sqlite')
    c = sqlite3.connect(history)
    cur = c.cursor()

    sel = "select moz_places.url, moz_places.visit_count from moz_places;"
    cur.execute(sel)
    res=cur.fetchall()
    
    t2 = tkinter.Tk()
    t2.title('Forensic Tool')
    t2.minsize(500,500)
    t2.configure(bg="black")


    for url,count in res:
        #print(url)
        t2.label = Label(t2,text=str(url))
        t2.label.place(relx = 0.05)
        t2.label.configure(bg="black")
        t2.label.configure(foreground="green2")
        t2.label.pack()
        




t = tkinter.Tk()
t.title('Forensic Tool')
t.grid_columnconfigure(0, weight=1)
t.grid_rowconfigure(0, weight=1)
t.minsize(1000,600)
t.configure(bg="black")

t.label1 = Label(t, text="Mozilla Browser Forensic Tool")
t.label1.place(relx=0.300, rely=0.035, height=40, width=550)
t.label1.configure(bg="black")
t.label1.configure(font=("Courier", 23,'bold'))
t.label1.configure(foreground="green2")

t.label2 = Label(t, text="Click on the buttons to see the forensic details")
t.label2.place(relx=0.265, rely=0.160, height=40, width=630)
t.label2.configure(bg="black")
t.label2.configure(font=("Courier", 13,'bold','italic'))
t.label2.configure(fg="white")

t.button1 = Button(t, text="Addons",command=lambda:show_downloads_history())
t.button1.place(relx=0.130, rely=0.40, height=40, width=98)
t.button1.configure(background="black")
t.button1.configure(font=("Courier", 15))
t.button1.configure(foreground="green2")

t.button2 = Button(t, text="Search",command=lambda:Dumpzilla(" --Search"))
t.button2.place(relx=0.480, rely=0.40, height=40, width=98)
t.button2.configure(background="black")
t.button2.configure(font=("Courier", 15))
t.button2.configure(foreground="green2")

t.button3 = Button(t, text="Bookmarks",command=lambda:Dumpzilla(" --Bookmarks"))
t.button3.place(relx=0.850, rely=0.40, height=40, width=120)
t.button3.configure(background="black")
t.button3.configure(font=("Courier", 15))
t.button3.configure(foreground="green2")

t.button4 = Button(t, text="Cookies",command=lambda:Dumpzilla(" --Cookies"))
t.button4.place(relx=0.130, rely=0.60, height=40, width=100)
t.button4.configure(background="black")
t.button4.configure(font=("Courier", 15))
t.button4.configure(foreground="green2")

t.button5 = Button(t, text="Downloads",command=lambda:Dumpzilla(" --Downloads"))
t.button5.place(relx=0.475, rely=0.60, height=40, width=120)
t.button5.configure(background="black")
t.button5.configure(font=("Courier", 15))
t.button5.configure(foreground="green2")

t.button6 = Button(t, text="History",command=lambda:show_downloads_history())
t.button6.place(relx=0.857, rely=0.60, height=40, width=102)
t.button6.configure(background="black")
t.button6.configure(font=("Courier", 15))
t.button6.configure(foreground="green2")


t.button7 = Button(t, text="Summary",command=lambda:Dumpzilla(folder_path+" "+'--Summary'))
t.button7.place(relx=0.480, rely=0.80, height=40, width=102)
t.button7.configure(background="black")
t.button7.configure(font=("Courier", 15))
t.button7.configure(foreground="green2")

t.mainloop()
