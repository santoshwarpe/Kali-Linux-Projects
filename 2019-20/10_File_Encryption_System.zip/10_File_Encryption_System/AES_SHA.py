import os
import sys
import hashlib
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from Cryptodome.Cipher import AES
import time

class EncryptionTool:
   
    def __init__(self, user_file, user_key, user_salt):
        self.user_file = user_file
        
        self.user_key = bytes(user_key, "utf-8")
        self.user_salt = bytes(user_key[::-1], "utf-8")

        self.file_extension = self.user_file.split(".")[-1]
        
        self.hash_type = "SHA256"

        
        self.encrypt_output_file = ".".join(self.user_file.split(".")[:-1]) + "." + self.file_extension[::] + ".aes"

        self.decrypt_output_file = self.user_file[:-5]

        self.hashed_key_salt = dict()

        self.hash_key_salt()

    def encrypt(self):
        cipher_object = AES.new(
            self.hashed_key_salt["key"],
            AES.MODE_CFB,
            self.hashed_key_salt["salt"]
        )

        with open(self.user_file, "rb") as f:
            content = f.read()

        encrypted_content = cipher_object.encrypt(content)

        with open(self.encrypt_output_file, "wb") as g:
            g.write(encrypted_content)

        del cipher_object

        os.remove(self.user_file)


    def decrypt(self):
        cipher_object = AES.new(
            self.hashed_key_salt["key"],
            AES.MODE_CFB,
            self.hashed_key_salt["salt"]
        )

        with open(self.user_file, "rb") as f:
            content = f.read()

        decrypted_content = cipher_object.decrypt(content)

        with open(self.decrypt_output_file, "wb") as g:
            g.write(decrypted_content)

        del cipher_object

    def hash_key_salt(self):

        hasher = hashlib.new(self.hash_type)
        hasher.update(self.user_key)

        self.hashed_key_salt["key"] = bytes(hasher.hexdigest()[:32], "utf-8")

        del hasher

        hasher = hashlib.new(self.hash_type)
        hasher.update(self.user_salt)

        self.hashed_key_salt["salt"] = bytes(hasher.hexdigest()[:16], "utf-8")
        
        del hasher


class MainWindow:


    Folder_name = ""
    if getattr(sys, "frozen", False):
        Folder_name = os.path.dirname(sys.executable)
    else:
        Folder_name = os.path.dirname(os.path.realpath(__file__))
    
    def __init__(self, root):
        self.root = root
        self._cipher = None
        self._file_url = tk.StringVar()
        self._secret_key = tk.StringVar()
        self._salt = tk.StringVar()
        self._status = tk.StringVar()
        self._status.set("Status:->")


        root.title("File Encryption using AES & MD5")

        root.configure(bg="#e7eaf6")

        # try:
        #     # root.iconbitmap(r"images/folder.jpeg")
        #     icon_img = tk.Image(
        #         "photo",
        #         file=self.Folder_name + "images/folder.jpeg"
        #     )
        #     root.call(
        #         "wm",
        #         "iconphoto",
        #         root._w,
        #         icon_img
        #     )
        # except Exception as e:
        #     pass

        self.menu_bar = tk.Menu(
            root,
            bg="Violet",
            relief=tk.FLAT
        )


        root.configure(
            menu=self.menu_bar
        )


        self.file_entry_label = tk.Label(
            root,
            text="Click SELECT FILE Button",
            bg="#e7eaf6",
            anchor=tk.W
        )
        self.file_entry_label.grid(
            padx=12,
            pady=(8, 0),
            ipadx=0,
            ipady=1,
            row=0,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

       

        self.select_btn = tk.Button(
            root,
            text="SELECT FILE",
            command=self.selectfile_callback,
            width=42,
            bg="#4CCBD7",
            fg="#000",
            bd=2,
            relief=tk.FLAT
        )
        self.select_btn.grid(
            padx=15,
            pady=8,
            ipadx=24,
            ipady=6,
            row=2,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        self.key_entry_label = tk.Label(
            root,
            text="Enter Password",
            bg="#e7eaf6",
            anchor=tk.W
        )
        self.key_entry_label.grid(
            padx=12,
            pady=(8, 0),
            ipadx=0,
            ipady=1,
            row=3,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        self.key_entry = tk.Entry(
            root,
            textvariable=self._secret_key,
            bg="#fff",
            exportselection=0,
            relief=tk.FLAT,
            show="*"

        )
        self.key_entry.grid(
            padx=15,
            pady=6,
            ipadx=8,
            ipady=6,
            row=4,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        
        
        self.encrypt_btn = tk.Button(
            root,
            text="ENCRYPT",
            # var = IntVar(),
            # self.wait_variable(var),
            # bitmap="hourglass",
            command=self.encrypt_callback,
            bg="#1AF158",
            fg="#000",
            bd=2,
            relief=tk.FLAT
        )
        self.encrypt_btn.grid(
            padx=(15, 6),
            pady=8,
            ipadx=6,
            ipady=6,
            row=7,
            column=0,
            columnspan=2,
            sticky=tk.W+tk.E+tk.N+tk.S
        )
        
        self.decrypt_btn = tk.Button(
            root,
            text="DECRYPT",
            command=self.decrypt_callback,
            bg="#F8272A",
            fg="#000",
            bd=2,
            relief=tk.FLAT
        )
        self.decrypt_btn.grid(
            padx=(6, 15),
            pady=8,
            ipadx=24,
            ipady=6,
            row=7,
            column=2,
            columnspan=2,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        self.clear_btn = tk.Button(
            root,
            text="CLEAR",
            command=self.clear_callback,
            bg="#E50F0F",
            fg="#fff",
            bd=2,
            relief=tk.FLAT
        )
        self.clear_btn.grid(
            padx=15,
            pady=(4, 12),
            ipadx=24,
            ipady=6,
            row=8,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        self.status_label = tk.Label(
            root,
            textvariable=self._status,
            bg="#e7eaf6",
            anchor=tk.W,
            justify=tk.LEFT,
            relief=tk.FLAT,
            wraplength=350
        )
        self.status_label.grid(
            padx=12,
            pady=(0, 12),
            ipadx=0,
            ipady=1,
            row=9,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        self.quit_btn = tk.Button(
            root,
            text="Quit",
            command=self.quit,
            width=10,
            bg="#FF5733",
            fg="#fff",
            bd=2,
            relief=tk.FLAT
        )
        self.quit_btn.grid(
            padx=70,
            pady=8,
            ipadx=5,
            ipady=5,
            row=10,
            column=1,
            columnspan=2,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        self.footer = tk.Label(
            root,
            text="Skill Development Lab Project : File Encryption System",
            font=("bold", 8),
            bg="#F6F7F6"
            
        )
        self.footer.grid(
            padx=12,
            pady=(0, 12),
            ipadx=0,
            ipady=5,
            row=12,
            column=0,
            columnspan=4,
            sticky=tk.W+tk.E+tk.N+tk.S
        )

        tk.Grid.columnconfigure(root, 0, weight=1)
        tk.Grid.columnconfigure(root, 1, weight=1)
        tk.Grid.columnconfigure(root, 2, weight=1)
        tk.Grid.columnconfigure(root, 3, weight=1)
        tk.Grid.columnconfigure(root, 3, weight=1)
        tk.Grid.columnconfigure(root, 3, weight=1)


    def selectfile_callback(self):
        name = filedialog.askopenfile()
        try:
            self._file_url.set(name.name)
           
        except Exception as e:
           
            pass

    def encrypt_callback(self):
        try:
            self._cipher = EncryptionTool(
                self._file_url.get(),
                self._secret_key.get(),
                self._salt.get()
            )
            self._cipher.encrypt()
            self._cipher = None
            # print("Your file is getting encrypted...")
            time.sleep(3)
            self._status.set("Hooray!File successfully Encrypted!")
        except Exception as e:
            
            self._status.set(e)

    def decrypt_callback(self):
        try:
            self._cipher = EncryptionTool(
                self._file_url.get(),
                self._secret_key.get(),
                self._salt.get()
            )
            self._cipher.decrypt()
            self._cipher = None
            self._status.set("Woo-hoo!File successfully Decrypted!")
        except Exception as e:
           
            self._status.set(e)

    def clear_callback(self):
        self._cipher = None
        self._file_url.set("")
        self._secret_key.set("")
        self._salt.set("")
        self._status.set("")

    def quit(self):
        try:
            self.root.destroy()
        except Exception as e:
            self._status.set(e)

    # def delay(self):
    #     try:
    #         print("Your file is encrypting...")
    #         time.sleep(2)
    #     except:
    #         pass


if __name__ == "__main__":
    ROOT = tk.Tk()
    MAIN_WINDOW = MainWindow(ROOT)
    ROOT.mainloop()
