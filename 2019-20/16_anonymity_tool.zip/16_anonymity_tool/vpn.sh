cd py/; python vpn.py
