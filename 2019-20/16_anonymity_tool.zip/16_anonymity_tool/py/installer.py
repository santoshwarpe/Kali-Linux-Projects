import os
import sys
from Tkinter import *

def VPN():
	vpn = 'sudo apt-get install openvpn -y'
	os.system(vpn)

def Mac():
	mac = 'sudo apt-get install macchanger -y'
	os.system(mac)

def Tor():
	tor = '''cd ..
sudo apt-get install tor -y
tar -xvJf tor-browser-linux64-9.0.1_en-US.tar.xz
'''
	os.system(tor)

def quit():
	os.system('clear')
	sys.exit() 

master = Tk()

T = master.title("Installer")

TT = Label(compound=CENTER, text="----------Welcome To Installing Part----------", font=10)
TT.pack(fill=BOTH, expand=1)

TX = Label(compound=CENTER, text="""1. Install Program That Was Not Install In Your OS!!!!""", font=4)
TX.pack(fill=BOTH, expand=1)

a = Button(compound=CENTER, text="Install Macchanger", command=Mac)
a.pack(side=LEFT, fill=BOTH, expand=1)

b = Button(compound=CENTER, text="Install Tor Browser", command=Tor)
b.pack(side=LEFT, fill=BOTH, expand=1)

c = Button(compound=CENTER, text="Download OpenVPN", command=VPN)
c.pack(side=LEFT, fill=BOTH, expand=1)

d = Button(compound=CENTER, text="QUIT", command=quit)
d.pack(side=LEFT, fill=BOTH, expand=1)

mainloop()

