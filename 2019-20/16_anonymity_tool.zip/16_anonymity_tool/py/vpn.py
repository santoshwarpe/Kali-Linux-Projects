import os
import sys
import string

def user():
	print('Please select your currently OS (operating system)')
	print('1. Kali Linux')
	print('2. Ubuntu')
	print('3. Linux Mint')
	print('COMING SOON...')
	print('4. EXIT')
	users = int(input('Please select 1 to 4 only : '))
	if users == 1:
		os.system('clear')
		print('Do you want to continue?')
		print('1. Yes')
		print('2. No')
		tk1 = int(input('Please select 1 to 3 only: '))
		if tk1 == 1:
			start()
		elif tk1 == 2:
			os.system('clear')
			user()
		else:
			os.system('clear')
			user()

	elif users == 2:
		os.system('clear')
		print('Do you want to continue?')
		print('1. Yes')
		print('2. No')
		tk = int(input('Please select 1 to 3 only: '))
		if tk == 1:
			start()
		elif tk == 2:
			os.system('clear')
			user()
		else:
			os.system('clear')
			user()

	elif users == 3:
		os.system('clear')
		print('Do you want to continue?')
		print('1. Yes')
		print('2. No')
		tk = int(input('Please select 1 to 3 only: '))
		if tk == 1:
			start()
		elif tk == 2:
			os.system('clear')
			user()
		else:
			os.system('clear')
			user()

	elif users == 4:
		os.system('clear')
		exit()
	else:
		os.system('clear')
		user()

def option():
	check = '''gnome-terminal --window -e "python option.py"'''
	os.system(check)

def multiS():
	print('Please select which VPN gate\n')
	print('1. VpnGate')
	print('2. VpnBook')
	print('COMING SOON...')
	print('3. RETURN')
	print('4. EXIT')

def error():
	print('Please enter a Valid Number')
	print('1. VpnGate')
	print('2. VpnBook')
	print('3. RETURN')
	print('4. EXIT')

def start():
	print('Welcome To VPN Services\n')
	print('Currently Only for Linux/Debian User\n')
	print('##### Running vpn in SU')
	print('Remember your password for sudo\n')
	print('Only US && EU contain VPNBook\n')
	print('Select Option')
	print('1. US')
	print('2. EU/FR')
	print('3. DE')
	print('4. JP')
	print('5. GE')
	print('6. AU')
	print('7. KO')
	print('8. RETURN')
	print('9. EXIT')
	option()

	while True:
		choice = int(input("Please select numbers from 1 to 9 only : "))
		G_US_filepath = '''cd ..
cd VPNGate/US/
sudo openvpn vpngate-US-udp1388.ovpn'''
		G_US_filepath1 = '''cd ..
cd VPNGate/US/
sudo openvpn vpngate-US-udp1194.ovpn'''
		G_US_filepath2 = '''cd ..
cd VPNGate/US/
sudo openvpn vpngate-US-udp1539.ovpn'''
		G_DE_filepath = '''cd ..
cd VPNGate/DE/
sudo openvpn vpngate-DE-udp1195.ovpn'''
		G_JP_filepath = '''cd ..
cd VPNGate/JP/
sudo openvpn vpngate-JP-udp1383.ovpn'''
		G_JP_filepath1 = '''cd ..
cd VPNGate/JP/
sudo openvpn vpngate-JP-udp1891.ovpn'''
		G_GE_filepath = '''cd ..
cd VPNGate/GE/
sudo openvpn vpngate-GE-udp1194.ovpn'''
		G_AU_filepath = '''cd ..
cd VPNGate/AU/
sudo openvpn vpngate-AU-udp1195.ovpn'''
		G_KO_filepath = '''cd ..
cd VPNGate/KO/
sudo openvpn vpngate-KO-udp1647.ovpn'''
		B_FR_filepath = '''cd ..
cd VPNBook/FR/
sudo openvpn vpnbook-fr1-tcp80.ovpn'''
		B_US_filepath= '''cd ..
cd VPNBook/US/
sudo openvpn vpnbook-us1-tcp80.ovpn'''

		if choice == 1:
			os.system('clear')
			multiS()
			while True:
				choice1 = int(input("Please select 1 to 4 only : "))
				os.system('clear')
				if choice1 == 1 :
					print('Available VPN Server\n')
					print('1. US Server UDP 1388\n')
					print('2. US Server UDP 1194\n')
					print('3. US Server UDP 1539\n')
					print('COMING SOON......')
					print('4. RETURN')
					print('5. EXIT')
					print('Control C or Ctrl c to stop the VPN server')
					while True:
						VpnUS1 = int(input("Please select available number only : "))
						if VpnUS1 == 1:
							os.system(G_US_filepath)
						elif VpnUS1 == 2:
							os.system(G_US_filepath1)
						elif VpnUS1 == 3:
							os.system(G_US_filepath2)
						elif VpnUS1 == 4:
							os.system('clear')
							start()
						elif VpnUS1 == 5:
							sys.exit()
						else:
							print('Please enter a valid number')
				elif choice1 == 2:
					print('Available VPN Server\n')
					print('Username : vpnbook && password : 2k3a6rw\n')
					print('1. US server tcp 80')
					print('2. RETURN')
					print('3. EXIT')
					print('Control C or Ctrl c to stop the VPN server')
					while True:
						VpnUS2 = int(input("Please select available number only : "))
						if VpnUS2== 1:
							os.system(B_US_filepath)
						elif VpnUS2 == 2:
							os.system('clear')
							start()
						elif VpnUS2 == 3:
							sys.exit()
						else:
							print('Please enter a valid number')
				elif choice1 == 3:
					start()
				elif choice1 == 4:
					sys.exit()
				else:
					error()
		elif choice == 2:
			os.system('clear')
			multiS()
			while True:
				choice2 = int(input("Please select 1 to 4 only : "))
				os.system('clear')
				if choice2 == 1:
					print('Available VPN Server\n')
					print('COMING SOON......')
					print('1. RETURN')
					print('2. EXIT')
					print('Control C or Ctrl c to stop the VPN server')
					while True:
						VpnEU1 = int(input("Please select available number only : "))
						if VpnEU1 == 1:
							os.system('clear')
							start()
						elif VpnEU1 == 2:
							sys.exit()
						else:
							print('Please enter a valid number')
				elif choice2 == 2:
					print('Available VPN Server\n')
					print('Username : vpnbook && password : 2k3a6rw\n')
					print('1. FR Server tcp 80\n')
					print('COMING SOON......')
					print('2. RETURN')
					print('3. EXIT')
					print('Control C or Ctrl c to stop the VPN server')
					while True:
						VpnEU2 = int(input("Please select available number only : "))
						if VpnEU2 == 1:
							os.system(B_FR_filepath)
						elif VpnEU2 == 2:
							os.system('clear')
							start()
						elif VpnEU2 == 3:
							sys.exit()
						else:
							print('Please enter a Valid Number')
				elif choice2 == 3:
					start()
				elif choice2 == 4:
					sys.exit()
				else:
					error()
		elif choice == 3:
			os.system('clear')
			print('Available VPN Server\n')
			print('1. DE Server UDP 1195\n')
			print('COMING SOON....')
			print('2. RETURN')
			print('3. EXIT')
			while True:
				VpnDE = int(input("Please select available number only : "))
				if VpnDE == 1:
					os.system(G_DE_filepath)
				elif VpnDE == 2:
					os.system('clear')
					start()
				elif VpnDE == 3:
					sys.exit()
				else:
					print('Please enter a Valid Number')
		elif choice == 4:
				os.system('clear')
				print('Available VPN Server\n')
				print('1. JP Server UDP 1383\n')
				print('2. JP Server UDP 1891\n')
				print('COMING SOON....')
				print('2. Return')
				print('3. EXIT')
				while True:
					VpnJP = int(input("Please select available number only : "))
					if VpnJP == 1:
						os.system(G_JP_filepath)
					elif VpnJP == 2:
						os.system(G_JP_filepath1)
					elif VpnJP == 3:
						os.system('clear')
						start()
					elif VpnJP == 4:
						sys.exit()
					else:
						print('Please enter a Valid Number')
		elif choice == 5:
				os.system('clear')
				print('Available VPN Server\n')
				print('1. GE Server UDP 1194\n')
				print('COMING SOON....')
				print('2. Return')
				print('3. EXIT')
				while True:
					VpnGE = int(input("Please select available number only : "))
					if VpnGE == 1:
						os.system(G_GE_filepath)
					elif VpnGE == 2:
						os.system('clear')
						start()
					elif VpnGE == 3:
						sys.exit()
					else:
						print('Please enter a Valid Number')

		elif choice == 6:
				os.system('clear')
				print('Available VPN Server\n')
				print('1. AU Server UDP 1877\n')
				print('COMING SOON....')
				print('2. Return')
				print('3. EXIT')
				while True:
					VpnAU = int(input("Please select available number only : "))
					if VpnAU == 1:
						os.system(G_AU_filepath)
					elif VpnAU == 2:
						os.system('clear')
						start()
					elif VpnAU == 3:
						sys.exit()
					else:
						print('Please enter a Valid Number')
		elif choice == 7:
				os.system('clear')
				print('Available VPN Server\n')
				print('1. KO Server UDP 1195\n')
				print('COMING SOON....')
				print('2. Return')
				print('3. EXIT')
				while True:
					VpnAU = int(input("Please select available number only : "))
					if VpnAU == 1:
						os.system(G_KO_filepath)
					elif VpnAU == 2:
						os.system('clear')
						start()
					elif VpnAU == 3:
						sys.exit()
					else:
						print('Please enter a Valid Number')

		elif choice == 8:
			os.system('clear')
			start()

		elif choice == 9:
			sys.exit()
	else:
		os.system('clear')
		print('Please enter a valid number')

os.system('clear')
user()
start()
