import sys
import os
import smtplib
from Tkinter import *

def install():
	Install = '''gnome-terminal --window -e "python installer.py"'''
	os.system(Install)


def leak():
	print ('change nameserver, using following ip')
	print ('nameserver 208.67.222.222')
	print ('nameserver 208.67.220.220')
	print ('nameserver 8.8.8.8')
	Leak = 'sudo gedit /etc/resolv.conf'
	os.system(Leak)
	
def tor():
	Tor = '''cd ..
		cd tor-browser_en-US/
		sudo ./start-tor-browser.desktop
		./start-tor-browser.desktop'''
	os.system(Tor)

def mac():
	Mac = '''sudo ifconfig eth0 down
		sudo ifconfig wlan0 down
		sudo macchanger -r eth0
		sudo ifconfig eth0 up
		sudo ifconfig wlan0 up'''
	os.system(Mac)
	print('After Changing Mac Address, please check your internet connection, reconnect is suggested')

def quit():
	os.system('clear')
	sys.exit()

master = Tk()

def test():
	DNS_Check = 'firefox https://www.dnsleaktest.com/'
	os.system(DNS_Check)

X = master.title("Annonimity tool")

T = Label(compound=CENTER, text="---------------DESCRIPTION---------------", font=16, bg="black", fg="white")
T.pack(fill=BOTH, expand=1)

TW = Label(compound=CENTER, text='''1. Always Remember To Run DNS LEAK TEST, make sure at least run STANDARD TEST and turn it off due to all program run in one console\n
1a) If DNS LEAK, please use Fix DNS LEAK and follow the instruction, *Note*Close DNS leak Test first(firefox)\n
2. Vpn and mac change first before Using TOR BROWSER TO ENSURE SAFETY\n
2a) If Tor stuck at loading screen, please use configure, isp click yes, change to obfs3, local depend\n
3.Before using tor browser  first edit tor-browser_en-US/Browser/start-tor-browser and comment out the lines \nif [ "`id -u`" -eq 0 ]; \nthen
\t	complain "The Tor Browser Bundle should not be run as root.  Exiting."
	exit 1
fi\n''', bg="black", fg="white", font=4)
TW.pack(fill=BOTH, expand=1)

a = Button(compound=LEFT, text="DNS Leak Test!!!", command=test,font=32, bg="black", fg="white")
a.pack(side=LEFT, expand=5,fill=BOTH)

b = Button(compound=CENTER, text="Change Mac Address", command=mac, bg="black", fg="white")
b.pack(fill=BOTH, expand=5)

c = Button(compound=CENTER,text="Tor Browser",command=tor, bg="black", fg="white")
c.pack(fill=BOTH, expand=5)

d = Button(compound=CENTER,text="FIX DNS LEAK!!!", command=leak, bg="black", fg="white")
d.pack(fill=BOTH, expand=5)

e = Button(compound=CENTER, text="QUIT Everything", command=quit, bg="black", fg="white", font=14)
e.pack(fill=BOTH, expand=5)

f = Button(compound=CENTER, text="INSTALLER", command=install, bg="black",fg="red",font=12)
f.pack(expand=6, fill=BOTH)

mainloop()
