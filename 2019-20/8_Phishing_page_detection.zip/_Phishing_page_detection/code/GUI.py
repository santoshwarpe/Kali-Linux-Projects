from Tkinter import * 
import Tkinter as tk
import urllib2



def onclick():
    try:
        str=url.get()
        response=urllib2.urlopen(str)
        print response.info()
        return 1
    except:
        print "This page is phish page"
    
'''if (1 == 1):
        print"a real URL"
    else:
        print "a phish page" '''

root = tk.Tk()
root.geometry('500x500')
root.title("Phishing Detection")

label_0 = Label(root, text="Web Link Validation",width=30,font=("bold", 20))
label_0.place(x=50,y=53)


label_1 = Label(root, text="Paste Your Link Below",width=25,font=("bold", 10))
label_1.place(x=160,y=130)

url = tk.Entry(root)
url.place(x=200,y=225)

'''
def gere(T_make):
    response=urllib2.urlopen(entry_1)
    print responseS.info()
    return(1)
'''
btn1 = tk.Button(root, text='Validate',width=25,bg='brown',fg='white',command=onclick).place(x=180,y=380)

root.mainloop()
