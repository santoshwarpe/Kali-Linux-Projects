from scapy.all import  *

for i in range(0,300):
	#packet = IP(dst="11.11.3.208")/TCP(flags="S",seq=10)
	packet = IP(dst="11.11.3.223")/TCP()
	send(packet)
