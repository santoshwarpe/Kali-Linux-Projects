from scapy.all import *

pkt = sniff(count=1000)
tcp_info=[]
other_info=[]
req_ack=0
ack=0
ips=[]
final=[]
protocol_cnt=[]
for i in range(1000):
	pkt_info=[]
	
	try:
		#print(pkt[i][IP].src)
		
        	src=pkt[i][IP].src
        	dst=pkt[i][IP].dst
		
        	protocol=pkt[i][IP].proto
        	length=pkt[i][IP].len
		protocol_cnt.append(protocol)
        	info=""
        	#print type(protocol)
        	if(protocol==6):
        	   
        	    ack=pkt[i][TCP].ack
        	    seq=pkt[i][TCP].seq
		    #print(type(ack))
        	    info="seq="+str(seq)+" , ack="+str(ack)
		    pkt_info.append(src)

		    pkt_info.append(dst)
		    pkt_info.append(protocol)
		    pkt_info.append(length)
		    pkt_info.append(ack)
		    pkt_info.append(seq)
		    tcp_info.append(pkt_info)
		    print "\nSource IP\tDestination IP\t\tProtocol\tLength\t\tInfo\n"
        	    print "\n",src,"\t",dst,"\t\t",protocol,"\t\t",length,"\t\t",info,"\n"
        	    #i+=1
        	else:
        	    info="None"
		    pkt_info.append(src)

		    pkt_info.append(dst)
		    pkt_info.append(protocol)
		    pkt_info.append(length)
		    
		    other_info.append(pkt_info)
			
        	    #i+=1
        	#print "\nSource IP\tDestination IP\t\tProtocol\tLength\t\tInfo\n"
        	#print "\n",src,"\t",dst,"\t\t",protocol,"\t\t",length,"\t\t",info,"\n"
		
		
			
			
	except:
		pass
        	#print("\nPacket Not Found")
                
for i in tcp_info:
	ips.append(i[0])
dst_ip=""		                                                                                                
list1=set(ips)				
uniqu_ip=(list(list1))	
print("\nIP Address in Network : \n")
for ip in uniqu_ip:
	print(ip)
proto=set(protocol_cnt)
protocol_cnt=(list(proto))


print("\nProtocols Used for Communication in Network : \n")
for protocol in protocol_cnt:
	if(protocol==6):
		print("TCP")
	elif(protocol==17):
		print("UDP")
	elif(protocol==2):
		print("IGMP")
	elif(protocol==1):
		print("ICMP")
	elif(protocol==4):
		print("IPv4")
	else:
		print("Other Protocol")
for ip in uniqu_ip:
	req_ack=0
	ack=0
	list1=[]	
	for i in tcp_info:
		if(i[0]==ip):
			if(ip!=i[1] and i[0]==ip and i[4]==0):
				req_ack+=1
				dst_ip=i[1]
			elif(ip!=i[1] and i[0]==ip and i[4]!=0):
				ack+=1
				dst_ip=i[1]
	list1.append(ip)
	list1.append(dst_ip)
	
	list1.append(req_ack)
	list1.append(ack)
	final.append(list1)
	
print("\nPackets Details :")
print("SRC IP\t\t\tDST IP\t\t\tACK=0 Cnt\t\tACK!=0 Cnt")
for i in final:
	print i[0],"\t\t",i[1],"\t\t",i[2],"\t\t",i[3]
for i in final:
	if(i[2]!=0 and i[3]!=i[2] and i[3]==0 and i[2]>100) :
		print "Flood Attack is performed on ",i[1],"from ",i[0]





