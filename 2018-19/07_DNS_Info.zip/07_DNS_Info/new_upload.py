import csv
ip_a = []
web = raw_input("Enter domain name : ")
ip_a.append(web)
n = input("Enter how many IP you want to enter : ")
for i in range(n):
	i_p = raw_input("Enter IP Address : ")
	ip_a.append(i_p)
with open('dname.csv','a') as f:
	w_write = csv.writer(f)
	w_write.writerow(ip_a)

print "Infi=ormation submitted successfully......"

