from pexpect import pxssh
import getpass
import csv

try:
	s = pxssh.pxssh()
	hostname = raw_input("Enter hostname: ")
	username = raw_input("username: ")
	password = getpass.getpass("password : ")
	b=raw_input("Enter domain name: ")
	s.login(hostname,username,password)
	a = "nslookup"+" "+b
	s.sendline(a)
	s.prompt()
	print s.before
	s.logout()
except pxssh.ExceptionPxssh,e:
	print "pxssh Failed to login "
	print str(e)



f = open('dname.csv','r')
reader = csv.reader(f)
table={}
for row in reader:
	a=[]
	for i in range(0,len(row)):
		a.append(row[i])
	table[row[0]] = a

name=b
ip=raw_input("Enter ip ontain via lookup: ")

a = b = True
for i in range(len(table)):
	if table.keys()[i]==name:
		print table
		a = True
		j=table.values()[i]
		for k in range(len(j)):
			if ip==j[k]:
				b=True
				break
			else:
				b=False
		break
	else:
		a=False

if a == True:
	if b == True:
		print "\n\nNo Spoofing occure"
	else:
		print"Spoofing occure"
else:
	print "No such webside\nPlease add IP and Domain this in file"
