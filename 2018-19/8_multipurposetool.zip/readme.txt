
welcome to                                                                                 
                      `-------`  -------       `---`                  -`            ``                      
                      /M++++++.  ++++sNd     `hho+ody                 o.            N/                      
                      /M            /m+      -M/.       +dyhd-  syhy` m:  myyydo  yyMdd-                     
                      /Myyyyyy    .hh.        `/oyyho` -M.      yd    M/  Mo  .M-   M/                      
                      /M         +m/                dy -M.      yy    M/  M+  .M-   M/ ,                     
                      /Myyyyyy +sMhyyyyy-    `ohhyyhy.  +dyyd/  yy    M/  Mhyyd+    dd::                     
                       ```````  ```````        ```      ``        `       M/  ``     `                      
                                                                          s-                

######### Instructions for EZ script execution ############
 1) Open terminal 
 2) Navigate to the folder with EZ script
 3) use command= 'python mainiApp.py'
 4) If any file name whi is needed to be mentioned is not in the same directory then provide the filename with extention as well as the path to that file ex: /Desktop/folderName/folderName2/fileName.ext
