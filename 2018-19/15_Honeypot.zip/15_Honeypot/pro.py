import time
import socket
from scapy.all import *

def getInput():
	msg = raw_input('Enter Msg Which to Print   : ')
	host = raw_input('Enter IP Address    : ')
	while True:
		try:
			port = int(raw_input('Enter Port No: '))
		except TypeError:
			print 'Error: Invalid port number.'
			continue
		else:
			if (port < 1) or (port > 65535):
				print 'You Should Check Machine be On !!!!'
				continue
			else:
				return (host, port, msg)


def writeLog(client, data=''):
	separator = '='*50
	fopen = open('./hackhoney.txt', 'a')
	fopen.write('Time: %s\nIP: %s\nPort: %d\nData: %s\n%s\n\n'%(time.ctime(), client[0], client[1], data, separator))
	fopen.close()

def main(host, port, msg):
	print "######################################################################\n"
	print '                       HoneyPot Service Has Started .....                     \n'
	print "######################################################################\n "
	
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind((host, port))
	s.listen(100)

	while True:
		(insock, address) = s.accept()
		print 'Connection from: %s:%d' % (address[0], address[1])
		for port in range(100,500):
			print ('Packet Sending to  port :',host,port)
		print("    !!!!!!!Atttempt Detected !!!!!!!!!!    ")
		try:
			insock.send('%s\n'%(msg))
			data = insock.recv(1024)
			insock.close()
		except socket.error, e:
			writeLog(address)
		else:
			writeLog(address, data)

        
if __name__=='__main__':
	try:
		stuff = getInput()
		main(stuff[0], stuff[1], stuff[2])
	except KeyboardInterrupt:
		print '\n\nBye!'
		exit(0)
	except BaseException, e:
		print 'Error: %s' % (e)
exit(1)
