#output
#output
root@kali:~# python passcrack.py 
please enter the MD5 Hash: 5f4dcc3b5aa765d61d8327deb882cf99
please enter the password file name: /usr/share/wordlists/rockyou.txt
Trying password number 1: 123456 
Trying password number 2: 12345 
Trying password number 3: 123456789 
Trying password number 4: password 

Match Found. 
Password is: password

