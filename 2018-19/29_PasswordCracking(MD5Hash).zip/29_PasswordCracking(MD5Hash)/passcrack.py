import md5

counter = 1

pass_in = raw_input("please enter the MD5 Hash: ")
pwfile = raw_input("please enter the password file name: ")

try:
        pwfile = open(pwfile, "r")
except:
        print "\nFile Not Found."
        quit()

for password in pwfile:
        filemd5 = md5.new(password.strip()).hexdigest()
        print "Trying password number %d: %s " % (counter,password.strip())

        counter += 1

	if pass_in == filemd5:
                print "\nMatch Found. \nPassword is: %s" %password
		break
				
else: print "\nPassword Not Found."



#output
root@kali:~# python passcrack.py 
please enter the MD5 Hash: 5f4dcc3b5aa765d61d8327deb882cf99
please enter the password file name: /usr/share/wordlists/rockyou.txt
Trying password number 1: 123456 
Trying password number 2: 12345 
Trying password number 3: 123456789 
Trying password number 4: password 

Match Found. 
Password is: password

