#import urllib.request
#urllib.request.urlretrieve("11.11.3.213", "local-filename")
import requests 
count=0
with open("url-req.txt","r") as file :
	for line in file :
		line=line.strip("\n")
		list=line.split("/")
		if  "jpg" in list[-1] or "jpeg" in list[-1]	or "png" in list[-1] or "txt" in list[-1]:
			print line
			r = requests.get("http://"+line)
		
			with open("".join(list),'wb+') as f:
				f.write(r.content)
