
import sys
import urllib
#import urllib.request



fullurl = raw_input("Please specify the vulnerable url: ")

resp = urllib.urlopen(fullurl)
body = resp.read()
try:
	fullbody = body.decode('utf-8')
except UnicodeDecodeError:
	print ("utf8 code cant decode byte 0xa0 in position 12389: invalid start byte")
	sys.exit(0)
if "You have an error in you SQL syntax" in fullbody:
	print ("The website is classic SQL injection vulnerable!")
	
else:
	print ("The website is not classic SQL injection vulnerable!")



#http://testphp.vulweb.com/listproducts.php?cat=1

