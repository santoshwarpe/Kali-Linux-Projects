from flask import Flask, render_template					#importing and using flask	
app = Flask(__name__)

@app.route("/home")								#defining the basicroute for request handler
def main():
	return render_template( "proj.html")
	
if __name__ == "__main__":
	app.run(debug=True)
